from __future__ import print_function
print('loading function')
def lambda_handler(event, context):
    return "hello by lambda function" 
