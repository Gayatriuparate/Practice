name = "joy"
age=29
print("hello my name is %s" %name)
print("age is %d"%age)
print("name=%s and age=%d"%(name,age))
