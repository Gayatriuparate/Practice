#!/user/bin/python
print ("hello")
