#define a variable with boolean value
it_is_tuesday = False
print("which day today")
#this if statement starts a new block
if it_is_tuesday:
	#this is inside the block
	print("it is tuesday")
#this is outside the block
print("Print this no matter what")
