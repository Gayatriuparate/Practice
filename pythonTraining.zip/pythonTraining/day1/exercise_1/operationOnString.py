name='Jane Smith'
len1 = len(name)
print (len1)
