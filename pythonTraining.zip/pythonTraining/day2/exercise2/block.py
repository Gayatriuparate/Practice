no_chickens= "No chickens here..."
def append_chickens(text):
	text=text+"rawwwwwk!"
	return text
print(append_chickens(no_chickens))
