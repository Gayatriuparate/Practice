MaxMark=80
tom_mark=67
print(("tom mark is %.3f%%"%(tom_mark/MaxMark*100)))
#%% is how we escape a literal % inside a string
