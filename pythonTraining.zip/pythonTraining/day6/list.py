animals=['cat','dog','fish','bison']
numbers=[1,2,3,4,5]
my_list=[]
things=['one','two','three']
print(things)