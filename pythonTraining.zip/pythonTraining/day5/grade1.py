mark=int(input("Enter Marks"))
if mark>=80:
	grade="A"
elif mark>=65:
	grade="B"
print(grade)
