x=0
if x>0 and 1/x<0.5:
	print("X is %f" %x)
if not x==5:
	print("I am not X")
