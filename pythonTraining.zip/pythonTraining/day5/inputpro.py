height=float(input("Enter the height of rectangle:"))
width=float(input("Enter the width of reactangle:"))
print("The area of rectangle is %f " %(width*height))
print("The area of rectangle is %d " %(width*height))
